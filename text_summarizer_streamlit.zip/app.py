import streamlit as st
from transformers import pipeline
from nltk.tokenize import sent_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import nltk

nltk.download('punkt')

st.set_page_config(page_title="Text Summarizer", layout="centered")

st.title("🧠 AI-Powered Text Summarizer")
st.write("Paste any long article or paragraph below to get both extractive and abstractive summaries.")

text_input = st.text_area("📋 Paste your article here:", height=300)

def extractive_summary(text, num_sentences=3):
    sentences = sent_tokenize(text)
    if len(sentences) <= num_sentences:
        return text
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(sentences)
    sim_matrix = cosine_similarity(X)
    sentence_scores = sim_matrix.sum(axis=1)
    top_sentence_indices = sentence_scores.argsort()[-num_sentences:][::-1]
    top_sentences = [sentences[i] for i in sorted(top_sentence_indices)]
    return ' '.join(top_sentences)

def abstractive_summary(text, max_len=130, min_len=30):
    summarizer = pipeline("summarization", model="t5-small", tokenizer="t5-small")
    input_text = "summarize: " + text.strip().replace("\n", " ")
    summary = summarizer(input_text, max_length=max_len, min_length=min_len, do_sample=False)
    return summary[0]['summary_text']

if st.button("✨ Summarize") and text_input.strip():
    with st.spinner("Generating summaries..."):
        extractive = extractive_summary(text_input)
        abstractive = abstractive_summary(text_input)
        
    st.subheader("🟡 Extractive Summary")
    st.write(extractive)
    
    st.subheader("🟢 Abstractive Summary")
    st.write(abstractive)